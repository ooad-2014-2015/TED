﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace animacije
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listTacaka = new List<Point>();
            listaBoja = new List<Color>();
            listaDebiljina = new List<int>();
            toolStripComboBox1.SelectedIndex = 0;
            pomocT=new List<Point>();
            pomocD=new List<int>();
            pomocC=new List<Color>();
            strBoja = Color.Black;
            strX = 0;
            strY = 0;
            deb = 1;
            stara=new Pen(this.BackColor,1);
            Mod = false;
        }

        Thread mojaNit;
        bool Mod;
        Color boja = Color.Black;
        List<Color> listaBoja;
        bool ludost = true;
        Pen stara;
        Color strBoja;
        int strX;
        int strY;
        int deb;

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);        
 	        if(k==1)
            {
                var controlGraphics = CreateGraphics();
                var paintEventArgs = new PaintEventArgs(controlGraphics, ClientRectangle);
                Pen nova = new Pen(boja, Convert.ToInt32(toolStripComboBox1.Text));
                if (!Mod)
                    paintEventArgs.Graphics.DrawLine(stara, prva, new Point(strX, strY));
                ludost = false;
                Form1_Paint(controlGraphics, paintEventArgs);
                paintEventArgs.Graphics.DrawLine(nova, prva, new Point(e.X, e.Y));
                stara.Width = Convert.ToInt32(toolStripComboBox1.Text);
                strX = e.X;
                strY = e.Y;
                if (e.Button == MouseButtons.Right)
                {
                    Mod = true;
                    /*Pen nova = new Pen(boja, Convert.ToInt32(toolStripComboBox1.Text));
                    paintEventArgs.Graphics.DrawLine(nova, prva, new Point(e.X, e.Y));
                    stara.Color = boja;
                    stara.Width = Convert.ToInt32(toolStripComboBox1.Text);*/
                }
                if (e.Button==MouseButtons.None)
                {
                    Mod = false;
                    /*Pen nova = new Pen(boja, Convert.ToInt32(toolStripComboBox1.Text));
                    if(!Mod)
                    paintEventArgs.Graphics.DrawLine(stara, prva, new Point(strX, strY));
                    ludost = false;
                    Form1_Paint(controlGraphics, paintEventArgs);
                    paintEventArgs.Graphics.DrawLine(nova, prva, new Point(e.X, e.Y));
                    stara.Width = Convert.ToInt32(toolStripComboBox1.Text);
                    strX = e.X;
                    strY = e.Y;*/
                }
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // MARIO
                int i = 30;
                e.Graphics.FillRectangle(new SolidBrush(Color.Red), 30, 30, 50, 10);
                i = i + 10;
                e.Graphics.FillRectangle(new SolidBrush(Color.Red), 20, i, 90, 10);
                i = i + 10;
                e.Graphics.FillRectangle(new SolidBrush(Color.DarkRed), 20, i, 30, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 50, i, 20, 50);
                e.Graphics.FillRectangle(new SolidBrush(Color.Olive), 70, i, 10, 20);
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 80, i, 10, 20);
                i = i + 10;
                e.Graphics.FillRectangle(new SolidBrush(Color.DarkRed), 10, i, 10, 30);
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 20, i, 10, 20);
                e.Graphics.FillRectangle(new SolidBrush(Color.DarkRed), 30, i, 10, 20);
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 40, i, 10, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 90, i, 20, 10);
                i = i + 10;
                e.Graphics.FillRectangle(new SolidBrush(Color.DarkRed), 40, i, 10, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 70, i, 10, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Olive), 80, i, 10, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 90, i, 30, 10);
                i = i + 10;
                e.Graphics.FillRectangle(new SolidBrush(Color.DarkRed), 10, i, 20, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 30, i, 20, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Olive), 70, i, 40, 10);
                i = i + 10;
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 30, i, 70, 10);
                i = i + 10;
                // i=100
                e.Graphics.FillRectangle(new SolidBrush(Color.Red), 20, i, 60, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Red), 10, i + 10, 100, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Red), 0, i + 20, 120, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Red), 20, i + 30, 80, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Blue), 40, i, 10, 70);
                e.Graphics.FillRectangle(new SolidBrush(Color.Blue), 70, i + 10, 10, 60);
                e.Graphics.FillRectangle(new SolidBrush(Color.Blue), 50, i + 20, 20, 40);
                i = 130;
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 0, i, 20, 30);
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 100, i, 20, 30);

                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 40, i, 10, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 70, i, 10, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Blue), 80, i, 10, 40);
                e.Graphics.FillRectangle(new SolidBrush(Color.Blue), 30, i, 10, 40);
                i += 10;
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 20, i, 10, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.Orange), 90, i, 10, 10);
                i += 10;
                e.Graphics.FillRectangle(new SolidBrush(Color.Blue), 20, i, 10, 20);
                e.Graphics.FillRectangle(new SolidBrush(Color.Blue), 90, i, 10, 20);
                i += 20;
                e.Graphics.FillRectangle(new SolidBrush(Color.DarkRed), 10, i, 30, 20);
                e.Graphics.FillRectangle(new SolidBrush(Color.DarkRed), 80, i, 30, 20);
                i += 10;
                e.Graphics.FillRectangle(new SolidBrush(Color.DarkRed), 0, i, 10, 10);
                e.Graphics.FillRectangle(new SolidBrush(Color.DarkRed), 110, i, 10, 10);

            // LUIGI

            i = 30;
            int j = 150;
            e.Graphics.FillRectangle(new SolidBrush(Color.SeaGreen), j + 30, 30, 50, 10);
            i = i + 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.SeaGreen), j + 20, i, 90, 10);
            i = i + 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Sienna), j + 20, i, 30, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange), j + 50, i, 20, 50);
            e.Graphics.FillRectangle(new SolidBrush(Color.Black), j + 70, i, 10, 20);
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange), j + 80, i, 10, 20);
            i = i + 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Sienna), j + 10, i, 10, 20);
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange), j + 20, i, 10, 20);
            e.Graphics.FillRectangle(new SolidBrush(Color.Sienna), j + 30, i, 10, 20);
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange), j + 40, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange), j + 90, i, 20, 10);
            i = i + 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Sienna), j + 40, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange), j + 70, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Black), j + 80, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange), j + 90, i, 30, 10);
            i = i + 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Sienna), j + 20, i, 20, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange), j + 30, i, 20, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Black),j+ 70, i, 40, 10);
            i = i + 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange),j+ 30, i, 60, 10);
            i = i + 10;
            // i=100
            e.Graphics.FillRectangle(new SolidBrush(Color.SeaGreen), j + 20, i, 80, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.SeaGreen),  j + 10, i + 10, 100, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.SeaGreen),  j + 0, i + 20, 120, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.SeaGreen),  j + 20, i + 30, 80, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.SlateBlue),  j + 40, i, 10, 70);
            e.Graphics.FillRectangle(new SolidBrush(Color.SlateBlue),  j + 70, i, 10, 60);
            e.Graphics.FillRectangle(new SolidBrush(Color.SlateBlue),  j + 50, i + 20, 20, 40);
            i = 130;
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange),  j + 0, i, 20, 30);
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange),  j + 100, i, 20, 30);

            e.Graphics.FillRectangle(new SolidBrush(Color.Orange),  j + 40, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange),  j + 70, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.SlateBlue),  j + 80, i, 10, 40);
            e.Graphics.FillRectangle(new SolidBrush(Color.SlateBlue),  j + 30, i, 10, 40);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange),  j + 20, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Orange),  j + 90, i, 10, 10);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.SlateBlue),  j + 20, i, 10, 20);
            e.Graphics.FillRectangle(new SolidBrush(Color.SlateBlue),  j + 90, i, 10, 20);
            i += 20;
            e.Graphics.FillRectangle(new SolidBrush(Color.Sienna),  j + 10, i, 30, 20);
            e.Graphics.FillRectangle(new SolidBrush(Color.Sienna),  j + 80, i, 30, 20);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Sienna),  j + 0, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Sienna),  j + 110, i, 10, 10);

            //ZELDA

            i = 30;
            j = 300;

            e.Graphics.FillRectangle(new SolidBrush(Color.Lime), j + 40, i, 60, 10);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Lime), j + 30, i, 80, 30);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 40, i, 60, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j + 10 , i, 10, 20);
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j + 120, i, 10, 20);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 30, i, 80, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j + 10, i + 10, 120, 20);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 30, i, 10, 30);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 100, i, 10, 30);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Lime), j + 80, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Lime), j + 50, i, 10, 10);
            i = i + 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 80, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 50, i, 10, 10);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j + 20, i, 100, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 120, i, 10, 20);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Lime), j + 20, i, 100, 60);
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j + 40, i, 60, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 60, i, 20, 10);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j + 50, i, 40, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j, i, 50, 60);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 110, i, 30, 10);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j - 10, i, 10, 50);
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j +10 , i, 10, 40);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 50, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j + 110, i, 10, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 120, i, 20, 10);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j, i, 30, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j + 50 , i, 10, 40);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 60, i, 20, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j+ 100, i,30, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j+130, i, 10, 10);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 70, i, 40, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j + 110, i, 30, 10);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 60, i, 20, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j + 120, i, 10, 10);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.Lime), j + 60, i, 50, 10);
            i += 10;
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 30 , i, 30, 20);
            e.Graphics.FillRectangle(new SolidBrush(Color.Moccasin), j , i, 50, 10);
            e.Graphics.FillRectangle(new SolidBrush(Color.DarkOrange), j + 80, i, 30, 10);

            // MEGAMAN
            if (ludost == false)
            {
                for (int l = 0; l < (listTacaka.Count / 2); l++)
                {
                    e.Graphics.DrawLine(new Pen(listaBoja[l], listaDebiljina[l]), listTacaka[l * 2], listTacaka[l * 2 + 1]);
                    ludost=true;
                }
            }
        }

        int k = 0;
        Point prva = new Point();
        Point druga = new Point();
        List<Point> listTacaka;
        List<int> listaDebiljina;

        List<Point> pomocT;
        List<int> pomocD;
        List<Color> pomocC;

        private void Form1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                k++;
                if (k == 2)
                {

                    druga.X = e.X;
                    druga.Y = e.Y;
                    listTacaka.Add(druga);
                    mojaFja();
                    listaBoja.Add(boja);
                    listaDebiljina.Add(Convert.ToInt32(toolStripComboBox1.Text));
                    ludost = false;
                    var controlGraphics = CreateGraphics();
                    var paintEventArgs = new PaintEventArgs(controlGraphics, ClientRectangle);
                    Form1_Paint(sender, paintEventArgs);
                    k = 0;
                }
                if (k == 1)
                {
                    prva.X = e.X;
                    prva.Y = e.Y;
                    strX = e.X;
                    strY = e.Y;
                    mojaFja();
                    listTacaka.Add(prva);
                }
            }
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (ToolStripButton p in toolStrip1.Items)
                    p.Checked = false;
            }
            catch(InvalidCastException)
            {

            }
        }

        void mojaFja()
        {
            try
            {
                foreach (ToolStripButton p in toolStrip1.Items)
                    if (p.Checked == true)
                    {
                        boja = (Color)p.BackColor;
                        p.Checked = false;
                        break;
                    }
            }
            catch (InvalidCastException)
            {

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           /* if(k==1)
            {
            var controlGraphics = CreateGraphics();
            var paintEventArgs = new PaintEventArgs(controlGraphics, ClientRectangle);
            pomocT.Add(new Point())
                MouseButtons.ge
            lista
            paintEventArgs.Graphics.DrawLine();
            }*/
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        
    }
}
